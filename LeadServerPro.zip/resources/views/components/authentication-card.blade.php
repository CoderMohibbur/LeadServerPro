<div>
    <div >
        {{ $slot }}
    </div>
</div>