<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css">
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>

    
    
    
    



    <!-- Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="font-sans antialiased">
    <div class="min-h-screen bg-white dark:bg-gray-800">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.filter_sitebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Theme Toggle Button -->
        <button id="theme-toggle" class="fixed top-4 right-4 bg-gray-800 text-white p-2 rounded-full">
            <span id="theme-toggle-light-icon" class="hidden">🌞</span>
            <span id="theme-toggle-dark-icon" class="hidden">🌙</span>
        </button>

        <!-- Page Heading -->
        <div class="p-4 sm:ml-64">
            <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700 mt-14">
                <div class=" flex items-center">
                    <h1 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                        <?php echo e(__('Lead Lists')); ?>

                    </h1>

                    

                    <!-- Modal toggle -->
                    <button data-modal-target="popup-modal" data-modal-toggle="popup-modal"
                        class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 ml-auto"
                        type="button">
                        Upload
                    </button>
                </div>
            </div>
        </div>

        <!-- Page Content -->
        <main>
            <div class="p-4 sm:ml-64">
                <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
                    <div class="container mx-auto">

                        <!-- Table Section -->
                        <div class="w-full bg-white p-5 shadow-md rounded-lg dark:bg-gray-700">
                            <div class="overflow-x-auto">
                                <table id="dataTable" class="dataTable table-auto border-collapse w-full">
                                    <thead>
                                        <tr>
                                            <th class="p-2.5">ID</th>
                                            <th class="p-2.5">LinkedIn Link</th>
                                            <th class="p-2.5">Company Name</th>
                                            <th class="p-2.5">Contact Name</th>
                                            <th class="p-2.5">Name Prefix</th>
                                            <th class="p-2.5">Full Name</th>
                                            <th class="p-2.5">First Name</th>
                                            <th class="p-2.5">Last Name</th>
                                            <th class="p-2.5">Email</th>
                                            <th class="p-2.5">Title Position</th>
                                            <th class="p-2.5">Person Location</th>
                                            <th class="p-2.5">Full Address</th>
                                            <th class="p-2.5">Company Phone</th>
                                            <th class="p-2.5">Company Head Count</th>
                                            <th class="p-2.5">Country</th>
                                            <th class="p-2.5">City</th>
                                            <th class="p-2.5">State</th>
                                            <th class="p-2.5">Tag</th>
                                            <th class="p-2.5">Source Link</th>
                                            <th class="p-2.5">Middle Name</th>
                                            <th class="p-2.5">Sur Name</th>
                                            <th class="p-2.5">Gender</th>
                                            <th class="p-2.5">Personal Phone</th>
                                            <th class="p-2.5">Employee Range</th>
                                            <th class="p-2.5">Company Website</th>
                                            <th class="p-2.5">Company LinkedIn Link</th>
                                            <th class="p-2.5">Company HQ Address</th>
                                            <th class="p-2.5">Industry</th>
                                            <th class="p-2.5">Revenue</th>
                                            <th class="p-2.5">Street</th>
                                            <th class="p-2.5">Zip Code</th>
                                            <th class="p-2.5">Rating</th>
                                            <th class="p-2.5">Sheet Name</th>
                                            <th class="p-2.5">Job Link</th>
                                            <th class="p-2.5">Job Role</th>
                                            <th class="p-2.5">Checked By</th>
                                            <th class="p-2.5">Review</th>
                                            <th class="p-2.5">Created At</th>
                                            <th class="p-2.5">Updated At</th>
                                            <th class="p-2.5">Action</th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Main modal -->
    <div id="popup-modal" tabindex="-1"
        class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <button type="button"
                    class="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-hide="popup-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
                <div class="p-4 md:p-5">
                    <!-- Move the button to the right with spacing -->
                    <div class="mb-4 flex justify-end space-x-4">

                    </div>
                    <form action="<?php echo e(route('sheets.store')); ?>" method="POST" enctype="multipart/form-data"
                        class="space-y-6">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-2 gap-6">
                            <!-- File Input -->
                            <div>
                                <label for="file" class="block text-gray-700 dark:text-gray-300">Select Your
                                    Sheet</label>
                                <input type="file" id="file" name="file" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 rounded-md shadow-sm">
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Working Date -->
                            <div>
                                <label for="sheet_working_date" class="block text-gray-700 dark:text-gray-300">Sheet
                                    Working
                                    Date</label>
                                <input type="date" id="sheet_working_date" name="sheet_working_date"
                                    value="<?php echo e(old('sheet_working_date', now()->toDateString())); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 rounded-md shadow-sm">
                                <?php $__errorArgs = ['sheet_working_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Sheet Name -->
                            <div>
                                <label for="sheet_name" class="block text-gray-700 dark:text-gray-300">Sheet
                                    Name</label>
                                <input type="text" id="sheet_name" name="sheet_name"
                                    value="<?php echo e(old('sheet_name')); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 rounded-md shadow-sm">
                                <?php $__errorArgs = ['sheet_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div x-data="{ open: false, search: '', selectedUser: '', selectedUserId: '' }" class="relative">
                                <label for="user_id" class="block text-gray-700 dark:text-gray-300">User</label>

                                <!-- Input for search -->
                                <input type="text" x-model="search" @focus="open = true" @click="open = true"
                                    class="w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm p-2"
                                    placeholder="Search User..." autocomplete="off">

                                <!-- Dropdown Menu -->
                                <div x-show="open" @click.outside="open = false"
                                    class="absolute mt-1 w-full bg-white dark:bg-gray-800 shadow-lg max-h-60 overflow-auto rounded-md z-10">
                                    <ul class="w-full py-1 text-sm text-gray-700 dark:text-gray-300">
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li
                                                x-show="search === '' || '<?php echo e($user->name); ?>'.toLowerCase().includes(search.toLowerCase())">
                                                <a href="#"
                                                    class="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                                                    @click.prevent="
                                                    selectedUser = '<?php echo e($user->name); ?>';
                                                    selectedUserId = '<?php echo e($user->id); ?>';
                                                    open = false;">
                                                    <?php echo e($user->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                                <!-- Selected User -->
                                <div x-show="selectedUser" class="mt-2 text-gray-600 dark:text-gray-300">
                                    <p>Selected User: <span x-text="selectedUser"></span></p>
                                </div>

                                <!-- Hidden Input for Form Submission -->
                                <input type="hidden" name="user_id" :value="selectedUserId">

                                <!-- Error handling -->
                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>

                        <div>
                            <button type="submit"
                                class="inline-block px-5 py-2 bg-blue-500 text-white font-medium rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-500 transition duration-200">
                                Upload Sheet
                            </button>
                            <button onclick="window.location.href='<?php echo e(route('sheets.index')); ?>'"
                                class="px-5 py-2 bg-blue-500 text-white font-medium rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700">
                                Back to List
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- Modal body -->
        </div>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    

    <script>
        window.addEventListener('DOMContentLoaded', () => {
            // Extract URL parameters
            const urlParams = new URLSearchParams(window.location.search);

            // Set the sheet ID in the filter input if it exists
            const sheetId = urlParams.get('sheet_id');
            if (sheetId) {
                $('#sheetIdFilter').val(sheetId);
            }

            // Set the user ID in the filter input if it exists
            const userId = urlParams.get('user_id');
            if (userId) {
                $('#userIdFilter').val(userId);
            }
            const dataTable = $('#dataTable').DataTable({
                processing: true,
                responsive: true,
                autoWidth: true,
                scrollX: true,
                scrollY: "75vh",
                scrollCollapse: true,
                pageLength: 25, // Default number of rows per page
                lengthMenu: [25, 50, 100, 200], // Dropdown options for rows per page
                ajax: {
                    url: '/leads/data',
                    type: 'GET',
                    data: function(d) {
                        // // Collect sheet_id and user_id dynamically
                        // ['sheetIdFilter', 'userIdFilter'].forEach((filterId) => {
                        //     const value = $(`#${filterId}`).val();
                        //     if (value) {
                        //         d[filterId.replace('Filter', '').toLowerCase()] = value; // Add sheet_id or user_id dynamically
                        //     }
                        // });

                        // Include sheet_id in the request payload
                        const sheetId = $('#sheetIdFilter').val();
                        if (sheetId) {
                            d.sheet_id = sheetId;
                        }

                        // Include user_id in the request payload
                        const userId = $('#userIdFilter').val();
                        if (userId) {
                            d.user_id = userId;
                        }
                        // Ensure the Sheet ID input exists and retrieve its value
                        // const sheetId = $('#sheetIdFilter').val();
                        // if (sheetId) {
                        //     d.sheet_id = sheetId; // Add sheet_id to the DataTable's request payload
                        // } else {
                        //     d.sheet_id = null; // Default to null if no Sheet ID is provided
                        // }
                        // Dynamically collect selected filter values
                        $('#filtersContainer input[type="checkbox"]:checked').each(function() {
                            const columnName = $(this).attr('name').replace('[]',
                                ''); // Remove [] from the name
                            if (!d[columnName]) {
                                d[
                                    columnName
                                ] = []; // Initialize array for the column if not already set
                            }
                            d[columnName].push($(this)
                                .val()); // Add selected value to the column array
                        });

                        // Collect values from Tagify inputs
                        $('#filtersContainer .tagify').each(function() {
                            const tagify = $(this).data(
                                'tagify'); // Retrieve the Tagify instance
                            if (tagify) {
                                const columnName = $(this).attr(
                                    'name'); // Use the input's name as the column
                                d[columnName] = tagify.value.map(tag => tag
                                    .value); // Add Tagify values as an array
                            }
                        });
                        console.log('Filters being sent:', d); // Debug log for verification
                    }
                },
                columns: [{
                        data: 'id'
                    },
                    {
                        data: 'linkedin_link'
                    },
                    {
                        data: 'company_name'
                    },
                    {
                        data: 'contact_name'
                    },
                    {
                        data: 'name_prefix'
                    },
                    {
                        data: 'full_name'
                    },
                    {
                        data: 'first_name'
                    },
                    {
                        data: 'last_name'
                    },
                    {
                        data: 'email'
                    },
                    {
                        data: 'title_position'
                    },
                    {
                        data: 'person_location'
                    },
                    {
                        data: 'full_address'
                    },
                    {
                        data: 'company_phone'
                    },
                    {
                        data: 'company_head_count'
                    },
                    {
                        data: 'country'
                    },
                    {
                        data: 'city'
                    },
                    {
                        data: 'state'
                    },
                    {
                        data: 'tag'
                    },
                    {
                        data: 'source_link'
                    },
                    {
                        data: 'middle_name'
                    },
                    {
                        data: 'sur_name'
                    },
                    {
                        data: 'gender'
                    },
                    {
                        data: 'personal_phone'
                    },
                    {
                        data: 'employee_range'
                    },
                    {
                        data: 'company_website'
                    },
                    {
                        data: 'company_linkedin_link'
                    },
                    {
                        data: 'company_hq_address'
                    },
                    {
                        data: 'industry'
                    },
                    {
                        data: 'revenue'
                    },
                    {
                        data: 'street'
                    },
                    {
                        data: 'zip_code'
                    },
                    {
                        data: 'rating'
                    },
                    {
                        data: 'sheet_name'
                    },
                    {
                        data: 'job_link'
                    },
                    {
                        data: 'job_role'
                    },
                    {
                        data: 'checked_by'
                    },
                    {
                        data: 'review'
                    },
                    {
                        data: 'created_at',
                        render: function(data) {
                            return moment(data).format(
                                'DD-MMM-YYYY h:mm A'); // e.g., 26-Dec-2024 06:34 AM
                        }
                    },
                    {
                        data: 'updated_at',
                        render: function(data) {
                            return moment(data).format(
                                'DD-MMM-YYYY h:mm A'); // e.g., 26-Dec-2024 06:34 AM
                        }
                    },
                    {
                        data: 'id', // The ID will be used for Edit, Show, Delete actions
                        render: function(data, type, row) {
                            return `
                                <button type="button" data-id="${data}" class="delete-btn text-white bg-red-700 hover:bg-red-800 focus:outline-none focus:ring-4 focus:ring-red-300 font-medium rounded-full text-sm px-3 py-1 text-center me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Delete</button>
                            `;
                        },
                        orderable: false, // Disable sorting for the action column
                        searchable: false // Disable searching for the action column
                    }

                ],

                layout: {
                    topEnd: ['search'],
                    topStart: {
                        pageLength: true,
                        buttons: ['copyHtml5', 'excelHtml5', 'csvHtml5', 'pdfHtml5', 'colvis', 'print']
                    }
                },
                initComplete: function() {
                    const api = this.api();

                    // Initialize Tagify for all inputs with the "tagify" class in filtersContainer
                    // $('#filtersContainer .tagify').each(function() {
                    //     const input = this;
                    //     const tagify = new Tagify(input);
                    //     $(input).data('tagify',
                    //     tagify); // Attach the Tagify instance to the input

                    //     // Handle Tagify events
                    //     tagify.on('add', (e) => {
                    //         console.log(`Tag added for input [${input.id}]:`, e.detail
                    //             .data);
                    //         dataTable.ajax.reload(); // Reload DataTable on tag addition
                    //     });

                    //     tagify.on('remove', (e) => {
                    //         console.log(`Tag removed for input [${input.id}]:`, e.detail
                    //             .data);
                    //         dataTable.ajax.reload(); // Reload DataTable on tag removal
                    //     });
                    // });
                    $('#filtersContainer .tagify').each(function() {
                        const input = this;
                        const columnName = $(input).attr(
                            'name'); // Get the name attribute to identify the column

                        // Initialize Tagify
                        const tagify = new Tagify(input, {
                            whitelist: [], // Start empty
                            dropdown: {
                                enabled: 1, // Show suggestions after 1 character
                                maxItems: 20, // Maximum items to display in dropdown
                                position: 'input', // Show dropdown near the input
                                closeOnSelect: false // Keep dropdown open after selecting
                            }
                        });

                        $(input).data('tagify',
                            tagify); // Attach the Tagify instance to the input

                        // Handle dynamic suggestions from the server
                        tagify.on('input', function(e) {
                            const searchTerm = e.detail.value;

                            fetch(
                                    `/leads/filters?column=${columnName}&term=${searchTerm}`
                                )
                                .then((res) => res.json())
                                .then((data) => {
                                    tagify.settings.whitelist = data[columnName] ||
                                        [];
                                    tagify.dropdown.show(
                                        searchTerm); // Show suggestions
                                })
                                .catch((err) => console.error(
                                    'Error fetching suggestions:', err));
                        });

                        // Reload DataTable on tag addition or removal
                        tagify.on('add', () => {
                            $('#dataTable').DataTable().ajax.reload();
                        });

                        tagify.on('remove', () => {
                            $('#dataTable').DataTable().ajax.reload();
                        });
                    });

                    // Search Row for Filterable Columns
                    // const columnsToSearch = [1, 2, 3, 5, 6]; // Indices of columns to include (0-based)
                    // const searchRow = $('<tr></tr>');
                    // $(api.table().header()).prepend(searchRow);

                    // api.columns().every(function(index) {
                    //     const column = this;

                    //     if (columnsToSearch.includes(index)) {
                    //         // Add an input to searchable columns
                    //         const title = $(column.header()).text();
                    //         $('<th><input type="text" placeholder="Search ' + title +
                    //                 '" style="width:100%;" /></th>')
                    //             .appendTo(searchRow)
                    //             .find('input')
                    //             .on('keyup change clear', function() {
                    //                 if (column.search() !== this.value) {
                    //                     column.search(this.value).draw();
                    //                 }
                    //             });
                    //     } else {
                    //         $('<th></th>').appendTo(searchRow);
                    //     }
                    // });
                    const columnsToSearch = [1, 2, 3, 5, 4,
                    6]; // Indices of columns to include (0-based)

                    // Add a second row for search filters
                    const tableHeader = $(api.table().header());
                    const searchRow = $(
                    '<tr class="search-row"></tr>'); // Add a class for easier styling
                    tableHeader.append(searchRow); // Append as the second row

                    api.columns().every(function(index) {
                        const column = this;

                        if (columnsToSearch.includes(index)) {
                            // Create a search input for searchable columns
                            const title = $(column.header()).text(); // Get column title
                            $('<th><input type="text" placeholder=""style="width:100%;padding: 1px;"/></th>')
                                .appendTo(searchRow)
                                .find('input')
                                .on('keyup change clear', function() {
                                    if (column.search() !== this.value) {
                                        column.search(this.value)
                                    .draw(); // Trigger filtering
                                    }
                                });
                        } else {
                            $('<th></th>').appendTo(
                            searchRow); // Add an empty cell for non-searchable columns
                        }
                    });

                }
            });
            // Handle Delete Button Clicks
            $(document).on('click', '.delete-btn', function() {
                var ID = $(this).data('id');

                if (confirm('Are you sure you want to delete this user?')) {
                    $.ajax({
                        url: '/lead-server/' + ID,
                        type: 'DELETE',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>' // Include CSRF token
                        },
                        success: function(response) {
                            alert('User deleted successfully!');
                            $('#dataTable').DataTable().ajax
                                .reload(); // Reload the table data after deletion
                        },
                        error: function() {
                            alert('An error occurred while deleting the user.');
                        }
                    });
                }
            });
        });
    </script>
</body>
<style>
    .dataTable th,
    .dataTable td {
        white-space: nowrap;
    }

    /* table.dataTable>thead>tr:first-child>th {
        background: transparent !important;
    } */

    thead input {
        border-radius: 5px !important;
    }

    .dropdown {
        display: none;
        position: absolute;
        background: #fff;
        border: 1px solid #ccc;
        max-height: 150px;
        overflow-y: auto;
        z-index: 1000;
    }

    .dropdown-item {
        padding: 5px 10px;
        cursor: pointer;
    }

    .dropdown-item:hover {
        background-color: #f0f0f0;
    }

    /* .tagify {
        @apply text-gray-800 bg-gray-100;
        @apply dark:text-white dark:bg-gray-900;
    } */
    .tagify {
        --placeholder-color: #6b7280; /* Default placeholder color for light mode */
        --placeholder-color-focus: #6b7280;
    }

    .dark .tagify {
        --placeholder-color: #6e6e6e; /* Placeholder color for dark mode */
        --placeholder-color-focus: #6e6e6e; /* Placeholder color for dark mode */
    }
</style>

</html>
<?php /**PATH C:\laragon\www\LeadServerPro\resources\views\leadServer\index2.blade.php ENDPATH**/ ?>