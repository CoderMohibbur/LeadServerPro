<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Ticket Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="p-6 sm:ml-64">
        <div class="p-6 bg-white dark:bg-gray-800 border border-gray-300 rounded-lg shadow-lg">
            <!-- Ticket Description -->
            <h3 class="font-semibold text-2xl text-indigo-600 mb-4">Ticket: <?php echo e($ticket->title); ?></h3>
            <p class="text-gray-700 dark:text-gray-300 text-lg mb-6"><?php echo e($ticket->description); ?></p>
            <hr class="my-4 border-t-2 border-indigo-500">

            <!-- Chat Box for Ticket Messages -->
            <div class="space-y-4 mb-6 overflow-y-auto max-h-96">
                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex <?php echo e($message->user_id == Auth::id() ? 'justify-end' : 'justify-start'); ?>">
                        <div class="max-w-xs p-4 rounded-lg shadow-md <?php echo e($message->user_id == Auth::id() ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-800'); ?>">
                            <p class="text-sm"><?php echo e($message->message); ?></p>
                            <p class="text-xs text-gray-400 mt-1"><?php echo e($message->created_at->format('d M Y, h:i A')); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Reply Form -->
            <form action="<?php echo e(route('tickets.storeAnswer', $ticket->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="message" class="block text-sm font-medium text-gray-700 mb-2">Your Reply</label>
                    <textarea id="message" name="message" rows="4" class="mt-1 block w-full p-3 border border-indigo-300 rounded-md focus:ring-2 focus:ring-indigo-500" required placeholder="Type your message here..."></textarea>
                </div>
                <div class="text-right">
                    <button type="submit" class="inline-block px-6 py-2 text-sm font-medium text-white bg-green-500 rounded-md hover:bg-green-600 focus:ring-4 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 transition">
                        Submit Reply
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LeadServerPro\resources\views\tickets\answer.blade.php ENDPATH**/ ?>