<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class=" flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight text-left">
                <?php echo e(__('All Sheets List')); ?>

            </h2>
            <button data-modal-target="popup-modal" data-modal-toggle="popup-modal"
                class="block text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 ml-auto"
                type="button">
                Upload
            </button>
        </div>

     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <div class="flex justify-between space-x-4 mb-4">
                <div>
                    <?php if(session('success')): ?>
                        <div class="px-4 py-3 mb-4 rounded relative border text-sm 
                               bg-green-100 border-green-400 text-green-700 
                               dark:bg-green-900 dark:border-green-700 dark:text-green-300"
                            role="alert">
                            <strong class="font-bold">Success!</strong>
                            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>

                </div>
                <div class=" flex space-x-4">
                    <div>
                        <label for="start_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Start
                            Date</label>
                        <input type="date" id="start_date" name="start_date"
                            class="block w-full px-4 py-2 text-sm border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600">
                    </div>
                    <div>
                        <label for="end_date" class="block text-sm font-medium text-gray-700 dark:text-gray-300">End
                            Date</label>
                        <input type="date" id="end_date" name="end_date"
                            class="block w-full px-4 py-2 text-sm border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600">
                    </div>
                </div>

            </div>
            <!-- Data Table -->
            <table id="sheetTable" class="table-auto w-full border-collapse ">
                <thead>
                    <tr>
                        <th>Sheet Name</th>
                        <th>File</th>
                        <th>Working Date</th>
                        <th>Client Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="dark:bg-gray-900 text-center">

                            <td class="px-4 py-2  dark:text-gray-300">
                                <a href="<?php echo e(route('leads.bySheet', $sheet->id)); ?>?sheet_id=<?php echo e($sheet->id); ?>"
                                    class="text-blue-500 hover:underline dark:text-blue-400">
                                    <?php echo e($sheet->sheet_name); ?>

                                </a>
                            </td>
                            <td class="px-4 py-2  dark:text-gray-300">
                                <?php if($sheet->file): ?>
                                    <a href="<?php echo e(asset('storage/' . $sheet->file)); ?>" target="_blank"
                                        class="text-blue-500 hover:underline dark:text-blue-400">
                                        <svg class="w-6 h-6 text-gray-800 dark:text-white inline-block mr-2"
                                            aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24"
                                            height="24" fill="none" viewBox="0 0 24 24">
                                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                                stroke-width="2"
                                                d="M4 15v2a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-2m-8 1V4m0 12-4-4m4 4 4-4" />
                                        </svg>
                                        Open File download
                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-500 dark:text-gray-400">No file available</span>
                                <?php endif; ?>
                            </td>

                            <td class="px-4 py-2  dark:text-gray-300"><?php echo e($sheet->sheet_working_date); ?></td>
                            <td class="px-4 py-2  dark:text-gray-300">
                                <a href="<?php echo e(route('leads.byUser', $sheet->user->id)); ?>?user_id=<?php echo e($sheet->user->id); ?>"
                                    class="text-blue-500 hover:underline dark:text-blue-400">
                                    <?php echo e($sheet->user->name); ?>

                                </a>
                            </td>
                            <td class="px-4 py-2  dark:text-gray-300">
                                <form action="<?php echo e(route('sheets.destroy', $sheet)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                        class="delete-btn text-white bg-red-700 hover:bg-red-800 focus:outline-none focus:ring-4 focus:ring-red-300 font-medium rounded-full text-sm px-3 py-1 text-center me-2 mb-2 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- Main modal -->
    <div id="popup-modal" tabindex="-1"
        class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-2xl max-h-full">
            <!-- Modal content -->
            <div class="relative bg-white rounded-lg shadow dark:bg-gray-700">
                <!-- Modal header -->
                <button type="button"
                    class="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-hide="popup-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
                <div class="p-4 md:p-5">
                    <!-- Move the button to the right with spacing -->
                    <div class="mb-4 flex justify-end space-x-4">

                    </div>
                    <form action="<?php echo e(route('sheets.store')); ?>" method="POST" enctype="multipart/form-data"
                        class="space-y-6">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-2 gap-6">
                            <!-- File Input -->
                            <div>
                                <label for="file" class="block text-gray-700 dark:text-gray-300">Select Your
                                    Sheet</label>
                                <input type="file" id="file" name="file" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 rounded-md shadow-sm">
                                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Working Date -->
                            <div>
                                <label for="sheet_working_date" class="block text-gray-700 dark:text-gray-300">Sheet
                                    Working
                                    Date</label>
                                <input type="date" id="sheet_working_date" name="sheet_working_date"
                                    value="<?php echo e(old('sheet_working_date', now()->toDateString())); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 rounded-md shadow-sm">
                                <?php $__errorArgs = ['sheet_working_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Sheet Name -->
                            <div>
                                <label for="sheet_name" class="block text-gray-700 dark:text-gray-300">Sheet
                                    Name</label>
                                <input type="text" id="sheet_name" name="sheet_name"
                                    value="<?php echo e(old('sheet_name')); ?>" required
                                    class="form-control w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 rounded-md shadow-sm">
                                <?php $__errorArgs = ['sheet_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div x-data="{ open: false, search: '', selectedUser: '', selectedUserId: '' }" class="relative">
                                <label for="user_id" class="block text-gray-700 dark:text-gray-300">User</label>

                                <!-- Input for search -->
                                <input type="text" x-model="search" @focus="open = true" @click="open = true"
                                    class="w-full mt-1 bg-gray-100 dark:bg-gray-700 dark:text-gray-300 rounded-md shadow-sm p-2"
                                    placeholder="Search User..." autocomplete="off">

                                <!-- Dropdown Menu -->
                                <div x-show="open" @click.outside="open = false"
                                    class="absolute mt-1 w-full bg-white dark:bg-gray-800 shadow-lg max-h-60 overflow-auto rounded-md z-10">
                                    <ul class="w-full py-1 text-sm text-gray-700 dark:text-gray-300">
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li
                                                x-show="search === '' || '<?php echo e($user->name); ?>'.toLowerCase().includes(search.toLowerCase())">
                                                <a href="#"
                                                    class="block px-4 py-2 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700"
                                                    @click.prevent="
                                        selectedUser = '<?php echo e($user->name); ?>';
                                        selectedUserId = '<?php echo e($user->id); ?>';
                                        open = false;">
                                                    <?php echo e($user->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>

                                <!-- Selected User -->
                                <div x-show="selectedUser" class="mt-2 text-gray-600 dark:text-gray-300">
                                    <p>Selected User: <span x-text="selectedUser"></span></p>
                                </div>

                                <!-- Hidden Input for Form Submission -->
                                <input type="hidden" name="user_id" :value="selectedUserId">

                                <!-- Error handling -->
                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-red-500 text-sm mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                        </div>

                        <div>
                            <button type="submit"
                                class="inline-block px-5 py-2 bg-blue-500 text-white font-medium rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-500 transition duration-200">
                                Upload Sheet
                            </button>
                            <button onclick="window.location.href='<?php echo e(route('sheets.index')); ?>'"
                                class="px-5 py-2 bg-blue-500 text-white font-medium rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700">
                                Back to List
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- Modal body -->
        </div>
    </div>

    <script>
        window.addEventListener('DOMContentLoaded', () => {
            $(document).ready(function() {
                const table = $('#sheetTable').DataTable({
                    processing: true,
                    responsive: true,
                    autoWidth: false,
                    scrollX: true,
                    layout: {
                        topEnd: ['search'],
                        topStart: {
                            pageLength: true,
                            buttons: ['copyHtml5', 'excelHtml5', 'csvHtml5', 'pdfHtml5', 'colvis',
                                'print'
                            ]
                        }
                    },
                });

                // Custom filtering function for date range
                $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
                    const startDate = $('#start_date').val() ? new Date($('#start_date').val()) :
                        null;
                    const endDate = $('#end_date').val() ? new Date($('#end_date').val()) : null;
                    const workingDate = new Date(data[
                    2]); // Adjust index based on Working Date column

                    if ((startDate === null && endDate === null) ||
                        (startDate === null && workingDate <= endDate) ||
                        (endDate === null && workingDate >= startDate) ||
                        (workingDate >= startDate && workingDate <= endDate)) {
                        return true;
                    }
                    return false;
                });

                // Event listeners for the date inputs
                $('#start_date, #end_date').on('change', function() {
                    table.draw();
                });
            });
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LeadServerPro\resources\views\sheets\index.blade.php ENDPATH**/ ?>