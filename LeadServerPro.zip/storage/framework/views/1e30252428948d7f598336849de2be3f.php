<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h1 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Ticket Lists')); ?>

            </h1>
            <a href="<?php echo e(route('tickets.create')); ?>"
                class="inline-block px-6 py-2 text-sm font-medium text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                Create Support Ticket
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">
            <!-- Tickets Table -->
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse border border-gray-200 dark:border-gray-700">
                    <thead class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                        <tr>
                            <th class="py-3 px-6 text-sm font-semibold border border-gray-200 dark:border-gray-700">Title</th>
                            <th class="py-3 px-6 text-sm font-semibold border border-gray-200 dark:border-gray-700">Status</th>
                            <th class="py-3 px-6 text-sm font-semibold border border-gray-200 dark:border-gray-700">Created At</th>
                            <th class="py-3 px-6 text-sm font-semibold border border-gray-200 dark:border-gray-700">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-800 dark:text-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                                <td class="py-3 px-6 border border-gray-200 dark:border-gray-700"><?php echo e($ticket->title); ?></td>
                                <td class="py-3 px-6 border border-gray-200 dark:border-gray-700">
                                    <span class="px-3 py-1 text-sm font-medium rounded-full
                                        <?php if($ticket->status === 'Open'): ?> bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100
                                        <?php elseif($ticket->status === 'In Progress'): ?> bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100
                                        <?php else: ?> bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100 <?php endif; ?>">
                                        <?php echo e($ticket->status); ?>

                                    </span>
                                </td>
                                <td class="py-3 px-6 border border-gray-200 dark:border-gray-700"><?php echo e($ticket->created_at->format('d M Y')); ?></td>
                                <td class="py-3 px-6 border border-gray-200 dark:border-gray-700">
                                    <!-- Edit, Delete, and Answer buttons -->
                                    <a href="<?php echo e(route('tickets.edit', $ticket->id)); ?>" class="text-blue-500 hover:text-blue-700">Edit</a> |
                                    <form action="<?php echo e(route('tickets.destroy', $ticket->id)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-500 hover:text-red-700">Delete</button>
                                    </form> |
                                    <a href="<?php echo e(route('tickets.answer', $ticket->id)); ?>" class="text-green-500 hover:text-green-700">Answer</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="py-3 px-6 text-center border border-gray-200 dark:border-gray-700">No tickets found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        // Debugging: Log all ticket data to console
        console.log('Tickets:', <?php echo json_encode($tickets, 15, 512) ?>);

        // If no tickets are found
        <?php if($tickets->isEmpty()): ?>
            console.log('No tickets found in the database.');
        <?php endif; ?>
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LeadServerPro\resources\views\tickets\index.blade.php ENDPATH**/ ?>