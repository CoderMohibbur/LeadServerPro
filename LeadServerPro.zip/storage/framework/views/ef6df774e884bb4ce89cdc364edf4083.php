<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                <?php echo e(__('Role Management')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="p-4 sm:ml-64">
        <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700">

            <?php if(session('success')): ?>
                <div class="alert alert-success mb-4">
                    <div class="bg-green-100 text-green-800 p-4 rounded">
                        <?php echo e(session('success')); ?>

                    </div>
                </div>
            <?php endif; ?>

            <div class="overflow-x-auto">
                <table id="role-management-table" class="table-auto w-full border-collapse dark:bg-gray-700">
                    <thead>
                        <tr>
                            <th class="px-4 py-2 text-gray-600 dark:text-gray-300">#</th>
                            <th class="px-4 py-2 text-gray-600 dark:text-gray-300">User Name</th>
                            <th class="px-4 py-2 text-gray-600 dark:text-gray-300">Email</th>
                            <th class="px-4 py-2 text-gray-600 dark:text-gray-300">Roles</th>
                            <th class="px-4 py-2 text-gray-600 dark:text-gray-300 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-4 py-2 text-gray-600 dark:text-gray-300"><?php echo e($loop->iteration); ?></td>
                                <td class="px-4 py-2 text-gray-600 dark:text-gray-300"><?php echo e($user->name); ?></td>
                                <td class="px-4 py-2 text-gray-600 dark:text-gray-300"><?php echo e($user->email); ?></td>
                                <td class="px-4 py-2">
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span
                                            class="badge bg-info text-gray-600 dark:text-gray-600 text-xs px-2 py-1 rounded bg-gray-200 dark:bg-gray-300">
                                            <?php echo e($role->name); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td class="px-4 py-2">
                                    <!-- Edit Button -->
                                    <button
                                        class="text-white bg-yellow-400 hover:bg-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-300 font-medium rounded-full text-sm px-3 py-1 text-center me-2 mb-2 dark:focus:ring-yellow-900"
                                        onclick="openEditModal(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>', <?php echo e($user->roles->pluck('id')); ?>)">
                                        Edit
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Edit Role Modal -->
    <div id="editRoleModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 items-center justify-center">
        <div class="bg-white rounded shadow p-6 w-1/3">
            <h2 class="text-lg font-bold mb-4">Edit Roles for <span id="modalUserName"></span></h2>
            <form action="<?php echo e(route('role.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_id" id="modalUserId">

                <div class="mb-4">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="block">
                            <input type="checkbox" name="roles[]" value="<?php echo e($role->name); ?>" id="roleCheckbox_<?php echo e($role->id); ?>">
                            <?php echo e($role->name); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="flex justify-end">
                    <button type="button" onclick="closeEditModal()"
                        class="bg-gray-500 text-white px-3 py-1 rounded hover:bg-gray-600 mr-2">Cancel</button>
                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">Save</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openEditModal(userId, userName, userRoles) {
            // Set user details in the modal
            document.getElementById('modalUserId').value = userId;
            document.getElementById('modalUserName').textContent = userName;
    
            // Reset checkboxes
            document.querySelectorAll('[id^=roleCheckbox_]').forEach(checkbox => checkbox.checked = false);
    
            // Check the user's current roles
            userRoles.forEach(roleId => {
                const checkbox = document.getElementById(`roleCheckbox_${roleId}`);
                if (checkbox) checkbox.checked = true;
            });
    
            // Show modal
            const modal = document.getElementById('editRoleModal');
            if (modal.classList.contains('hidden')) {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
            }
        }
    
        function closeEditModal() {
            const modal = document.getElementById('editRoleModal');
            modal.classList.remove('flex');
            modal.classList.add('hidden');
        }
    
        window.addEventListener('DOMContentLoaded', () => {
            $('#role-management-table').DataTable();
        });
    </script>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\LeadServerPro\resources\views\role-management\index.blade.php ENDPATH**/ ?>