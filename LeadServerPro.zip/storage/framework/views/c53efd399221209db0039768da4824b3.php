<div>
    <div >
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH C:\laragon\www\LeadServerPro\resources\views\components\authentication-card.blade.php ENDPATH**/ ?>