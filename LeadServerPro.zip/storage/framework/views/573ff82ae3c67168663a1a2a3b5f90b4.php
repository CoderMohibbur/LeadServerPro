<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Ticket')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="p-6 sm:ml-64">
        <div class="p-4 border border-gray-300 rounded-lg bg-white dark:bg-gray-800">
            <form action="<?php echo e(route('tickets.update', $ticket->id)); ?>" method="POST" id="ticket-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- Use PUT for update -->

                <!-- Title -->
                <div class="mb-4">
                    <label for="title" class="block text-sm font-medium text-gray-700">Title</label>
                    <input type="text" id="title" name="title" value="<?php echo e(old('title', $ticket->title)); ?>" class="mt-1 block w-full p-2 border border-gray-300 rounded-md" required>
                </div>

                <!-- Status -->
                <div class="mb-4">
                    <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                    <select id="status" name="status" class="mt-1 block w-full p-2 border border-gray-300 rounded-md" required>
                        <option value="Open" <?php if($ticket->status == 'Open'): ?> selected <?php endif; ?>>Open</option>
                        <option value="In Progress" <?php if($ticket->status == 'In Progress'): ?> selected <?php endif; ?>>In Progress</option>
                        <option value="Closed" <?php if($ticket->status == 'Closed'): ?> selected <?php endif; ?>>Closed</option>
                    </select>
                </div>

                <!-- Submit Button -->
                <div class="text-right">
                    <button type="submit" class="inline-block px-6 py-2 text-sm font-medium text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 transition">
                        Update Ticket
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        // JavaScript Debugging: Log form data to console before submission
        document.getElementById('ticket-form').addEventListener('submit', function(event) {
            // Log the title and status to console for debugging
            console.log('Form submission detected!');
            console.log('Title:', document.getElementById('title').value);
            console.log('Status:', document.getElementById('status').value);

            // Optional: Check if fields are filled before submitting
            if (!document.getElementById('title').value || !document.getElementById('status').value) {
                console.log('Error: Title or Status is missing');
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\LeadServerPro\resources\views\tickets\edit.blade.php ENDPATH**/ ?>